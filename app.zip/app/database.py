# MongoDB driver Asynchronous 
import motor.motor_asyncio
#client = motor.motor_asyncio.AsyncIOMotorClient('mongodb://localhost:27017')
client2 = motor.motor_asyncio.AsyncIOMotorClient("mongodb+srv://dhairyahil:desh1596@cluster0.5jhvx.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
db2 = client2.productIo


import pymongo
conn_str  = "mongodb+srv://dhairyahil:desh1596@cluster0.5jhvx.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
client = pymongo.MongoClient(conn_str, serverSelectionTimeoutMS=5000)
db = client["productIo"]
collection = db["posts"]


try:
    #print(client.server_info())
    print("server running")
except Exception:
    print("Unable to connect to the server.")