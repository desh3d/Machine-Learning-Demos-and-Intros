from pydantic import Json
from .. import schemas
from fastapi import FastAPI, Response, status, HTTPException, Depends, APIRouter
from ..database import client, db, client2, db2
from bson.json_util import dumps
from bson.objectid import ObjectId

from typing import List
#from pandas import DataFrame
router = APIRouter(prefix="/bulk", tags=["products"])


collection = db["products"] #- Pymogocursor, syncronous, creates one if not present



@router.post("/add")
def add_products(products: List[schemas.Product]):
    c = 0
    for i in products:
        c+=1
        #print(i.dict())
        collection.insert_one(i.dict())
    #query = collection.insert_many(products)
    #print(query.acknowledged)
    #print(query.inserted_ids)
    return c


@router.put("/update")
def bulk_update(change: list):
    print(change)
    query = collection.update_many(change[0],{"$set":change[1]})
    return query.matched_count