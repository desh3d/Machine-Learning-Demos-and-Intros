from fastapi import FastAPI, HTTPException
#from database import client
from fastapi.middleware.cors import CORSMiddleware
from .routers import user, product, bulk
from .database import client, db




# uvicorn main:app --reload
app = FastAPI()



@app.get("/test1")
def read_root():
    return{"My app is working fine"}


@app.get("/dbinfo")
def get_info():
    dbinfo = {
        "collections":db.list_collection_names(),
        "products collection exists?": "products" in db.list_collection_names(),
    }
    return dbinfo




app.include_router(user.router)
app.include_router(product.router)
app.include_router(bulk.router)

origins = [
    "https://www.google.com",
    "http://localhost",
    "http://localhost:8080",
    "*" # Every domain in world
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
