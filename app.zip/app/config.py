from multiprocessing import connection
from pymongo import MongoClient
import asyncio
import motor.motor_asyncio

async def get_server_info():
    # replace this with your MongoDB connection string
    conn_str = "mongodb+srv://dhairyahil:desh1596@cluster0.5jhvx.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
    # set a 5-second connection timeout
    client = motor.motor_asyncio.AsyncIOMotorClient(conn_str, serverSelectionTimeoutMS=5000)
    try:
        print(await client.server_info())
    except Exception:
        print("Unable to connect to the server.")


#loop = asyncio.get_event_loop()
#loop.run_until_complete(get_server_info())
#connection = MongoClient() by default local connects to localhost



#client = MongoClient("mongodb+srv://dhairyahil:desh1596@cluster0.5jhvx.mongodb.net/myFirstDatabase?retryWrites=true&w=majority") #server_api=ServerApi('1'))
#db = client.testDatabaseNAme
#print(db)