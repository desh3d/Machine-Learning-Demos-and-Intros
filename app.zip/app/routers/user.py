
from fastapi import FastAPI, Response, status, HTTPException, Depends, APIRouter
#from .. models import User

from .. database import client, db
from .. import schemas


collection = db["users"] 
router = APIRouter(prefix="/users", tags=["Users"])

@router.get("/")
def find_all():
    #print(client.local.user.find())
    #print(schemas.UserOut(client.user.find()))
    #print(client.productIo.posts.find())
    #print(schemas.usersEntity(client.local.user.find()))
    return {"some data":"some content"}


