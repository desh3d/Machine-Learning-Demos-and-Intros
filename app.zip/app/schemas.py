from sqlite3 import Date
from unittest.mock import Base
from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import Optional

class Product(BaseModel):
    name: str
    price: int
    available: bool = False
    created_at: datetime = datetime.now()



class postCreate(Product):
    pass

class postUpdate(Product):
    pass