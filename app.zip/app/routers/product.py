from pydantic import Json
from .. import schemas
from fastapi import FastAPI, Response, status, HTTPException, Depends, APIRouter
from ..database import client, db, client2, db2
from bson.json_util import dumps
from bson.objectid import ObjectId
#from pandas import DataFrame
router = APIRouter(prefix="/products", tags=["products"])


collection = db["products"] #- Pymogocursor, syncronous, creates one if not present

# @router.get("/")
# async def find_all():
#collection = db2["posts"]  # - Asynchonous, motor
#     query = {}
#     mongodoc = collection.find(query) #query object
#     motorDoc = await db2["posts"].find().to_list(10)
#     # for x in mydoc:
#     #     print(x)
#     print(type(motorDoc))
#     print(motorDoc)
#     return dumps(motorDoc)#motorDoc[0] #dumps(list(mydoc))





@router.get("/")
def find_all():
    query = {}
    mongocurser = list(collection.find(query)) #query object
    print(mongocurser)
    json_data = dumps(mongocurser)
    # with open('data.json', 'w') as file:
    #         file.write(json_data)
    return dumps(mongocurser)#motorDoc[0] #dumps(list(mydoc))




@router.get("/{id}")
def find_one(id: str, response: Response):
    query = {"_id":ObjectId(id)}
    result = collection.find_one(query)
    print(result)
    json_data = dumps(result)
    #print(json_data)
    return dumps(result)


@router.post("/")
def add_product(product: schemas.postCreate):
    print(product.dict())
    query = collection.insert_one(product.dict())
    success = collection.find_one(product.dict())
    return dumps(success)



@router.put("/{id}")
def update_product(id: int, response: Response, product: schemas.postUpdate):
    #print(product.dict())
    # adds new fields if not present, same id
    #query = collection.find_one_and_update({"_id":ObjectId(id)}, {"$set":product.dict()}) #updates if dosent exist,
    # create entire new document
    query = collection.find_one_and_replace({"_id":ObjectId(str(id))}, product.dict()) #updates if dosent exist,
    #query = collection.update_one({"_id":ObjectId(id)}, {"$set":product.dict()})
    success = collection.find_one(product.dict())
    #print(query) return old object
    return dumps(success)



@router.delete("/{id}")
def delete_product(id: str):
    query = collection.delete_one({"_id":ObjectId(id)})
    return f"document with {id} Deleted"


